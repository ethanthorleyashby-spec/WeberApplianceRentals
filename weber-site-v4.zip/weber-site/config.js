// ============================================================
//  EDIT THESE THREE LINES — everything else updates itself.
// ============================================================
const SITE = {
  phone: "(801) 784-8384",                                        // your business phone, as you want it shown
  linkSet: "https://buy.stripe.com/bJe00ifzfeCs9mrdbD2wU05",      // Stripe Payment Link for the $50/month set
  linkSingle: "https://buy.stripe.com/6oUfZgfzffGw7ejb3v2wU09",   // Stripe Payment Link for the single machine ($60 every 2 months)
};
// ============================================================

// ---------- Language handling ----------
// Each page sets <html lang="en|es" data-alt="path to the same page in the other language">.
// The visitor's choice is remembered on their device; the first visit to a home page shows a picker.
const LANG_KEY = "war-lang";
function getSavedLang() { try { return localStorage.getItem(LANG_KEY); } catch (e) { return null; } }
function saveLang(l) { try { localStorage.setItem(LANG_KEY, l); } catch (e) {} }

(function redirectToSavedLanguage() {
  const html = document.documentElement;
  const saved = getSavedLang();
  const alt = html.getAttribute("data-alt");
  if (saved && alt && saved !== html.lang && !location.search.includes("nolang")) {
    location.replace(alt);
  }
})();

function showLanguagePicker() {
  const html = document.documentElement;
  const overlay = document.createElement("div");
  overlay.className = "lang-picker";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-label", "Choose your language / Elija su idioma");
  overlay.innerHTML =
    '<div class="lang-card">' +
      '<div class="lang-icon" aria-hidden="true">🌐</div>' +
      '<h2>Choose your language</h2>' +
      '<p class="lang-es">Elija su idioma</p>' +
      '<div class="lang-buttons">' +
        '<button type="button" class="btn btn-primary" data-choose="en">English</button>' +
        '<button type="button" class="btn btn-primary" data-choose="es">Español</button>' +
      '</div>' +
    '</div>';
  document.body.appendChild(overlay);
  document.body.style.overflow = "hidden";
  overlay.querySelectorAll("[data-choose]").forEach(btn => {
    btn.addEventListener("click", () => {
      const choice = btn.getAttribute("data-choose");
      saveLang(choice);
      if (choice !== html.lang) {
        location.href = html.getAttribute("data-alt");
      } else {
        overlay.remove();
        document.body.style.overflow = "";
      }
    });
  });
  overlay.querySelector("[data-choose]").focus();
}

document.addEventListener("DOMContentLoaded", () => {
  const html = document.documentElement;
  const isSpanish = html.lang === "es";
  const stripeLocale = isSpanish ? "?locale=es" : "";

  const digits = SITE.phone.replace(/[^0-9+]/g, "");
  document.querySelectorAll("[data-phone]").forEach(el => (el.textContent = SITE.phone));
  document.querySelectorAll("[data-tel]").forEach(el => (el.href = "tel:" + digits));
  document.querySelectorAll("[data-sms]").forEach(el => (el.href = "sms:" + digits));
  document.querySelectorAll("[data-link-set]").forEach(el => (el.href = SITE.linkSet + stripeLocale));
  document.querySelectorAll("[data-link-single]").forEach(el => (el.href = SITE.linkSingle + stripeLocale));
  document.querySelectorAll("[data-year]").forEach(el => (el.textContent = new Date().getFullYear()));

  // Header language switch: remember the new choice before navigating
  document.querySelectorAll("[data-set-lang]").forEach(a => {
    a.addEventListener("click", () => saveLang(a.getAttribute("data-set-lang")));
  });

  // First visit to a home page: ask which language
  if (html.hasAttribute("data-picker") && !getSavedLang()) showLanguagePicker();
});
